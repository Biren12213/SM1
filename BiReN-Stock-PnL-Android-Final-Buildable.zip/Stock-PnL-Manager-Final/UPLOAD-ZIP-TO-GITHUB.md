# Upload ZIP directly to GitHub

GitHub will store the Android project ZIP as a normal file. It will not execute a workflow located inside that ZIP.

Therefore, in the repository create this one small file:

`.github/workflows/build-from-uploaded-zip.yml`

Use the copy supplied with this project. After that, upload/replace `BiReN-Stock-PnL-Android-Final.zip` in the repository. The workflow extracts it and builds the APK automatically.
